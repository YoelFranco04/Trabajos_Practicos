<?php ini_set("display_errors","1"); ?>
<?php
require_once "../entities/radio.php";

echo "<h1> Test Radio </h1><br>";
$radio1 = new Radio("200w","Nokia");
echo $radio1."<br>";

?>