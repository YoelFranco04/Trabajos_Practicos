<?php ini_set("display_errors","1"); ?>
<?php
require_once "../entities/auto_clasico.php";
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";
require_once "../entities/auto_nuevo.php";
require_once "../entities/bondi.php";

// $vehiculo1 = new Vehiculo("dad","ada","dd","dd", ",1000000");
// echo $vehiculo1."<br>";


echo "<h1> Test VEHICULO </h1>";

echo "<h3>-- Test Auto CLASICO --</h3>";
$clasico1= new AutoClasico(
            "verde",
            "Fiat",
            "208",
            "no tiene",
            "no tiene",
            "30000"
        );
echo $clasico1->fabricarClasico()."<br><br>";
$clasico1->agregarRadio("200w","Nokia" );
echo $clasico1->fabricarClasico();


echo "<h3>-- Test Auto NUEVO --</h3>";
$nuevo1 = new AutoNuevo(
            "Rojo",
            "Fiat",
            "208",
            "500w",
            "3000w",
            "25000"        
);

echo $nuevo1->fabricarNuevo()."<br><br>";
$nuevo1->cambiarRadio("100w","Nokia");
echo $nuevo1->fabricarNuevo();


echo "<h3>-- Test Bondi   --</h3>";
$bondi1 = new Bondi(
            "Rojo",
            "mercedes",
            "tipo bondi",
            "no tiene",
            "no tiene",
            "28000"
);
echo $bondi1->fabricarBondi()."<br><br>";
$bondi1->agregarRadio("350w","Samsung");
echo $bondi1->fabricarBondi()."<br>";










?>