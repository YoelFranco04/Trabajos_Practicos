<?php
require_once "../entities/vehiculo.php";

class Bondi extends Vehiculo {
    public function __construct(
                    $color,
                    $marca,
                    $modelo,
                    $potenciaRadio,
                    $marcaRadio,
                    $precio) {
        parent::__construct($color,$marca,$modelo,$marcaRadio,
        $potenciaRadio, $precio);
    }
    
    public function fabricarBondi(){
        return "El BONDI --> COLOR: ".$this->getColor()." ,MARCA: ".$this->getMarca()." ,MODELO: ".$this->getModelo().
        $this->getRadio()."PRECIO($): ".$this->getPrecio();
    }     
}
?>