<?php
require_once "../entities/vehiculo.php";

class AutoClasico extends Vehiculo {
    public function __construct(
                $color,
                $marca,
                $modelo,
                $potenciaRadio,
                $marcaRadio,
                $precio) {
            parent::__construct($color,$marca,$modelo,$marcaRadio,
            $potenciaRadio, $precio);
    }
    

    public function fabricarClasico(){
        return "El Auto CLASICO --> COLOR: ".$this->getColor()." ,MARCA: ".$this->getMarca()." ,MODELO: ".$this->getModelo().
        $this->getRadio()."PRECIO($): ".$this->getPrecio();
    }   
}
?>