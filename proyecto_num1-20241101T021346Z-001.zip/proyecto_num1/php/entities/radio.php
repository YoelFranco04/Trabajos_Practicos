<?php
class Radio{
    private $potencia;
    private $marca;

    public function __construct(string $potencia, string $marca){
        $this->potencia = $potencia;
        $this->marca = $marca;
    }
    

    public function __tostring(){
        return ", RADIO-->(Potencia de: ".$this->potencia." y de la Marca: ".$this->marca.") y ";
    }
}
?>