<?php 
require_once "../entities/radio.php";
abstract class Vehiculo {
    private $color;
    private $marca;
    private $modelo;
    private $radio;
    private $precio;

    public function __construct(
        string $color, 
        string $marca, 
        string $modelo,
        string $marcaRadio, 
        string $potenciaRadio,
        string $precio ){
        $this->color = $color;
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->radio = new Radio ($potenciaRadio, $marcaRadio );   
        $this->precio = $precio;
    }


    public function getColor() : string {
        return $this->color;
    }

    public function getMarca() : string {
        return $this->marca;
    }
    public function getModelo() : string {
        return $this->modelo;}

    public function getPrecio(): string {
        return $this->precio;}

    public function getRadio(): string {
        return $this->radio;}

    



    public function cambiarRadio(string $potenciaRadio, string $marcaRadio)  {
        return $this->radio= new Radio ( $potenciaRadio, $marcaRadio );
    }
    public function agregarRadio(string $potenciaRadio, string $marcaRadio)  {
        return $this->radio= new Radio ( $potenciaRadio, $marcaRadio );
    }
    
    
}
?>