function calcularValorIMC() {
    //alert("Se ejecuto la función!")
    peso = parseFloat(document.getElementById("nro1").value);
    altura = parseFloat(document.getElementById("nro2").value);
    metro = (altura / 100);
    resultado = peso / (metro * metro);

    document.getElementById("resultado").value = resultado.toFixed(2)


    if (resultado < 15) {
        estado = "delgadez muy severa";
    } else if (resultado >= 15 && resultado < 15.9) {
        estado = "delgadez severa moderada";
    } else if (resultado >= 16 && resultado < 18.4) {
        estado = "delgadez leve";
    } else if (resultado >= 18.5 && resultado < 24.9) {
        estado = "Peso normal";
    } else if (resultado >= 25 && resultado < 29.9) {
        estado = "sobrepeso";
    } else if (resultado >= 30 && resultado < 34.9) {
        estado = "obesidad moderada";
    } else if (resultado >= 35 && resultado < 39.9) {
        estado = "obesidad severa";
    } else if (resultado >= 40) {
        estado = "obesidad mórbida.";
    }

    document.getElementById("estado").value = estado;
}