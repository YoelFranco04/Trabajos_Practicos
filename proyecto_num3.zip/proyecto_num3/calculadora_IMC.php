<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora IMC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="icon" href="icons/question-square.png">
    <link rel="stylesheet" href="css/style1.css">
</head>

<body>
    <!-- TITULO -->
    <form class="m-3 p-3">
        <div class="border-black border border-5 rounded-4 container-lg p-2 bg-info-subtle">
            <h1 class=" text success text-center">CALCULADORA DE IMC Y SU ESTADO</h1>
        </div>
    </form>


    <form class="m-3 p-3" method="POST">
        <div class="border-black border border-5 rounded-4 container-lg p-3 bg-body-tertiary rounded">

            <!-- Peso -->
            <div class="mb 3 row">
                <label for="nro1" step="0.01" class="col-sm-3 col-form-label text-primary text-center">Peso(en kg)</label>
                <div class="col-sm-7">
                    <input type="number" step="0.01" class="form-control text-emphasis" id="nro1" name="nro1"
                            required placeholder="Ingrese su peso en kilogramos">
                </div>
            </div><br>
       
            <!-- Altura -->
            <div class="mb 3 row">
                <label for="nro2" step="0.01" class="col-sm-3 col-form-label text-primary text-center">Altura(en cm)</label>
                <div class="col-sm-7">
                    <input type="number" step="0.01" class="form-control text-emphasis" id="nro2" name="nro2"
                            required placeholder="Ingrese su altura en centimetros">
                </div>
            </div>

            <!-- Botones -->
            <div class="m-4 mb 3 row">
                <button type="submit" class="btn btn-success col-sm-3 m-2 mx-auto d-block">Calcular</button>
                <button type="reset" class="btn btn-danger col-sm-3 m-2 mx-auto d-block">Borrar</button>
            </div>

            <!-- Resultado Valor y Estado IMC -->
            <div class="mb 3 row">
                <label for="resultado"  class="col-sm-3 col-form-label text-primary text-center p-3">Resultado del IMC y Estado IMC</label>
                <div class="col-sm-7">
                    <div class="form-control" id="resultado" name="resultado">
                        <?php include_once "php/test/IMC.php";?>
                    </div> 
                </div> 
            </div>
        </div>
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js " integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz " crossorigin="anonymous ">
    </script>
</body>

</html>