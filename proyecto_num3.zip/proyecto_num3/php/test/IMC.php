<?php      

        if (isset($_REQUEST['nro1']) && isset($_REQUEST['nro2'])) {

        
        $peso = (float)$_REQUEST['nro1'];
        $altura = (float)$_REQUEST['nro2'] /100; 
        $valorImc = $peso / ($altura * $altura);
        
        echo "Su valor de IMC es:    ".number_format($valorImc,2)."<br>";


        $estado="";

        if ($valorImc < 15) {
                $estado = "delgadez muy severa";
            } else if ($valorImc >= 15 && $valorImc < 15.9) {
                $estado = "delgadez severa moderada";
            } else if ($valorImc >= 16 && $valorImc < 18.4) {
                $estado = "delgadez leve";
            } else if ($valorImc >= 18.5 && $valorImc < 24.9) {
                $estado = "Peso normal";
            } else if ($valorImc >= 25 && $valorImc < 29.9) {
                $estado = "sobrepeso";
            } else if ($valorImc >= 30 && $valorImc < 34.9) {
                $estado = "obesidad moderada";
            } else if ($valorImc >= 35 && $valorImc < 39.9) {
                $estado = "obesidad severa";
            } else if ($valorImc >= 40) {
                $estado = "obesidad mórbida.";
            }
        
        echo "Su Estado de IMC es:   ". $estado;}
?>