<?php 
interface I_Consecionaria{
    function listarVehiculos();
    function vehiculoMasCaro();
    function vehiculoMasBarato();
    function vehiculoPorLetra();
    function vehiculosOrdenadosMayorMenor();
    function vehiculosOrdenadosNatural();
}

?>