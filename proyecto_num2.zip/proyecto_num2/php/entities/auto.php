<?php 
require_once "../entities/vehiculo.php";
class Auto extends Vehiculo{
    private $puertas;
    public function __construct(
        string $marca,
        string $modelo,
        string $puertas,
        string $precio){
        parent::__construct($marca,$modelo,$precio);
        $this->puertas = $puertas;
        }
        public function __tostring(){
            return "Marca: ".$this->getMarca()." // Modelo: ".$this->getModelo()." // Puertas: ".$this->puertas.
            " // Precio: $".$this->getPrecio();
        }
}
?>