<?php 
require_once "../entities/consecionaria.php";
require_once "../entities/I_consecionaria.php";
abstract class Vehiculo extends Consecionaria{
    private $marca;
    private $modelo;
    private $precio;

    public function __construct(
        string $marca,
        string $modelo,
        string $precio){      
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->precio = $precio;
    }

    public function getMarca(){
        return $this->marca;
    }
    public function getModelo(){
        return $this->modelo;
    }
    public function getPrecio(){
        return $this->precio; 
    }

    
}
?>