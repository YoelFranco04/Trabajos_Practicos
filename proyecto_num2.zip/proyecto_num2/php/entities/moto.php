<?php 
require_once "../entities/vehiculo.php";
class Moto extends Vehiculo{
    private $cilindrada;

    public function __construct(
                string $marca,
                string $modelo,
                string $cilindrada,
                string $precio){
                parent::__construct($marca,$modelo,$precio);
                $this->cilindrada= $cilindrada;
    }

    public function __tostring(){
        return "Marca: ".$this->getMarca()." // Modelo: ".$this->getModelo()." // Cilindrada: ".$this->cilindrada.
        " // Precio: $".$this->getPrecio();
    }

}
?>