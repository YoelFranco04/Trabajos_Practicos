<?php
require_once "../entities/I_consecionaria.php";
class consecionaria implements I_Consecionaria{

    
    private $vehiculos = [];

    public function agregarVehiculo($vehiculo) {
        $this->vehiculos[] = $vehiculo;
    }
    

    public function listarVehiculos(){
        foreach ($this->vehiculos as $vehiculo){
            echo $vehiculo."<br>";}
    }

    public function vehiculoMasCaro() {

        $masCaro = $this->vehiculos[0];
        foreach ($this->vehiculos as $vehiculo) {
            if ($vehiculo->getPrecio() > $masCaro->getPrecio()) {
                    $masCaro = $vehiculo;
            }
        }
        echo "Vehiculo mas caro es: ".$masCaro->getMarca()." ".$masCaro->getModelo()."<br>"; 
    }
        
    
    
    public function vehiculoMasBarato(){

        $masBarato = $this->vehiculos[0];
        foreach ($this->vehiculos as $vehiculo) {
            if ($vehiculo->getPrecio() < $masBarato->getPrecio()) {
                    $masBarato = $vehiculo;
            }
        }
        echo "Vehiculo mas caro es: ".$masBarato->getMarca()." ".$masBarato->getModelo()."<br>";  
    }
    

    public function vehiculoPorLetra() { 
        $modeloBusacdo = 'Y';
        $modeloEncontrado = null;
        
        foreach ($this->vehiculos as $vehiculo) {
            
            if(stripos($vehiculo->getModelo(),$modeloBusacdo) !== false ) {
                $modeloEncontrado = $vehiculo;
                break;
            }
        }
        echo "Vehiculo que contiene en el modelo la letra 'Y': ".
        $modeloEncontrado->getModelo()." ".$modeloEncontrado->getMarca()." ".$modeloEncontrado->getPrecio()."<br><br>";}


    public function vehiculosOrdenadosMayorMenor(){
        usort($this->vehiculos, function($a, $b) { 
            return $b->getPrecio() <=> $a->getPrecio();
        });

        foreach ($this->vehiculos as $vehiculo){
            echo $vehiculo->getMarca()." ".$vehiculo->getModelo()."<br>";
        }
    }
            

    public function vehiculosOrdenadosNatural(){
            natsort($this->vehiculos);
            foreach ($this->vehiculos as $vehiculo){
                echo $vehiculo."<br>";
            }
    }
}

?>