<?php ini_set("display_errors","1"); ?>
<?php

require_once "../entities/consecionaria.php";
require_once "../entities/vehiculo.php";
require_once "../entities/moto.php";
require_once "../entities/auto.php";

echo "<h1> Consecionaria </h1>";
echo "prueba<br>";
$auto1= new Auto("Insano","GOAT","20000","5");
echo $auto1."<br><br>";
$moto1= new Moto("Insano","Goat","20000","5");
echo $moto1."<br>";
?>