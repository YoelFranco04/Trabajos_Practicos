<?php ini_set("display_errors","1"); ?>
<?php
require_once "../entities/I_consecionaria.php";
require_once "../entities/consecionaria.php";
require_once "../entities/vehiculo.php";
require_once "../entities/moto.php";
require_once "../entities/auto.php";


echo "<h1> Consecionaria </h1>";

$consecionaria1= new Consecionaria();
$consecionaria1->agregarVehiculo(new Auto("Peogeot","206","4",200000.00));
$consecionaria1->agregarVehiculo(new Moto("Honda","Titan","125c",60000.00));
$consecionaria1->agregarVehiculo(new Auto("Peogeot","208","5",250000.50));
$consecionaria1->agregarVehiculo(new Moto("Yamaha","YRB","160c",80500.50));


$consecionaria1->listarVehiculos();

echo "<br>======================================================<br><br>";

$consecionaria1->vehiculoMasCaro();
$consecionaria1->vehiculoMasBarato();
$consecionaria1->vehiculoPorLetra();

echo "======================================================<br><br>";

$consecionaria1->vehiculosOrdenadosMayorMenor();

echo "<br>======================================================<br><br>";

$consecionaria1->vehiculosOrdenadosNatural();

?>